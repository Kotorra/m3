lista_contactos=[("Juan Pérez", "juanperez@example.com"),("María López", "marialopez@example.com"),(("María Lechuga", "marialechuga@example.com"))]

def agregar_contacto(nombre, email):
	lista_contactos.append((nombre,email))